#include <bits/stdc++.h>

using namespace std;


int main(){
	
	int n, a;
	char op;
	
	priority_queue< int, vector<int>, greater<int> > sacola;
	
	while(scanf("%d", &n), n){
		
		
		for(int i=0; i<n; i++){
			scanf(" %c %d", &op, &a);
			if(op == 'd') sacola.push(a);
			else{
				if(i==n-1) break;
				while(sacola.size()>=a) sacola.pop();
			}
		}
		int ans = -1;
		if(sacola.size() >= a){
			ans=0;
			while(sacola.size()) {
				ans+= sacola.top();
				sacola.pop();
			}
		}
		printf("%d\n", ans);
		
	}
	
}
