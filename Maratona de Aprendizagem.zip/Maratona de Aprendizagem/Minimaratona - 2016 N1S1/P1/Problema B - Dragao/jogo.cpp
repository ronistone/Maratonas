#include <bits/stdc++.h>

using namespace std;

int main(){
	int v, cont=1;
	int ini, fim, meio; ini = 0; fim = 1000000;
	while(1){
		
		meio = (ini+fim)/2;
		
		printf("%d\n", meio);
		scanf("%d", &v);
		
		if(v == -1) fim = meio-1; // o numero que eu chutei e maior
		else if(v == 1) ini = meio+1; // o numero que eu chutei e menor
		else {
			printf("HA!! LULULULULU\nCONT = %d\n", cont);
			break;
		}
		
		if(ini > fim) {
			printf("NAO ACHOU\n");
			break;
		}
		
		cont++;
		
	}
	
}
