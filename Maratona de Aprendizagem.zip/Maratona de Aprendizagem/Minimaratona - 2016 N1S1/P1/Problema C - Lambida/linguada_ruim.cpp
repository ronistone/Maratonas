#include <bits/stdc++.h>
using namespace std;

typedef long long int ll;


const ll N = 1e2 + 10;
 
ll v[N];
 
int main () {
 
    ll test;
    scanf("%lld", &test);
    while (test-- > 0) {
 
        ll n, x; scanf("%lld %lld", &n, &x);
 
        for (ll i = 0; i < n; ++i)
            scanf("%lld", &v[i]);
 
        ll ans = LLONG_MIN;
        
        for (ll i = 0; i <= n - x; ++i) {
 
            ll current = 0;
             
            for (ll j = i; j < i + x; ++j)
                current += v[j];
 
            ans = max(ans, current);
        }
 
        printf("%lld\n", ans);
    }
     
    return 0;
}
