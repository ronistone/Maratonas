#include <bits/stdc++.h>

typedef long long ll;

using namespace std;

double r, custo[300];
int cupom[300];
int c;

bool consigo_comprar(int i)
{
	double gastei;
	int cupom_atual;
	gastei = 0.0;
	cupom_atual = c-1;
	
	for(int j = i; j >= 0; j--)
	{
		if(cupom_atual >= 0)
		{
			gastei += (double) ((100 - cupom[cupom_atual]) * custo[j])/100.0;	
			cupom_atual--;
		}
		else
			gastei += custo[j];
	}
	if( r >= gastei ) return true;
	return false;
}
				

main()
{
	int n, t, i;
	scanf("%d", &t);
	while(t--)
	{
		scanf("%d%d%lf", &n, &c, &r);
		
		for(i=0; i<n; i++)
			scanf("%lf", &custo[i]);
		for(i=0; i<c; i++)
			scanf("%d", &cupom[i]);
			
		sort(custo,custo+n);
		sort(cupom,cupom+c);
		
		int posso_comprar = -1;
		
		for(i=0; i<n; i++)
		{
			
			if(consigo_comprar(i))
				posso_comprar = max(posso_comprar, i+1);
			else
				break;
		}
		printf("%d\n", posso_comprar);
	}
}
		
		
