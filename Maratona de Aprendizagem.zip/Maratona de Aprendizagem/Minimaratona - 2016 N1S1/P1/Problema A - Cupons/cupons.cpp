#include <bits/stdc++.h>

using namespace std;

#define N 101010

int n, c, cupom[N];
double R, joia[N];

bool consegue(int x){
	
	double sum = 0.0;
	
	for(int i=x, j=c-1; i>=0; i--){
		
		if(j>=0){
			sum += ((double)(100 - cupom[j])*joia[i])/100.0;
			j--;
		}else sum+= joia[i];
		
	}
	return sum <= R;
}

int main(){
	
	int t;
	
	
	scanf("%d", &t);
	while(t--){
		
		scanf("%d %d %lf", &n, &c, &R);
		
		for(int i=0; i<n; i++) scanf("%lf", &joia[i]);
		
		for(int i=0; i<c; i++) scanf("%d", &cupom[i]);
		
		sort(joia, joia+n);
		sort(cupom, cupom+c);
		
		int ini=0, fim = n-1;
		int ans = 0;
		
		while(ini <= fim){
			
			int meio = (ini+fim)/2;
			
			if(consegue(meio)){
				ans = max(ans, meio+1);
				
				ini = meio+1;
				
			}else fim = meio-1;
		}
		printf("%d\n", ans);
	}
}
