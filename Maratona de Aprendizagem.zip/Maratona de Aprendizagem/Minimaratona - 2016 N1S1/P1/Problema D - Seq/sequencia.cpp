#include <bits/stdc++.h>

using namespace std;

int main(){
	//~ int mat[101][101];
	int vet[1010];
	
	vet[0] = 0;
	for(int i=1; i<=1000; i++) vet[i] = i + vet[i-1];

	int t, n, n2;
	cin >> t;
	while(t--){
		
		cin >> n;
		
		n2 = 2*n -1;
		
		int dif;
		for(int i=1; i<= n2; i++){
			for(int j = 1; j<= n2; j++){
				
				dif = min(i-1, min(j-1, min(n2-i, n2-j)));
				printf("%d%c", vet[n-dif], j==n2 ? '\n' : ' ');
			}
		}
		printf("\n");
		
	}
	
}
