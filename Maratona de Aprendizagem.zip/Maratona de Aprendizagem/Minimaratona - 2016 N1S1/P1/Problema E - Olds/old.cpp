#include <bits/stdc++.h>

using namespace std;

int main(){
	
	int m[3][3];
	
	
	while(scanf("%d%d%d %d%d%d %d%d%d", &m[0][0], &m[0][1], &m[0][2], &m[1][0], &m[1][1], &m[1][2], &m[2][0], &m[2][1], &m[2][2]) != EOF){
		
		int linha[]={0, 0, 0};
		int coluna[]={0, 0, 0};
		int diag1, diag2 = diag1 = 0;
		for(int i=0; i<3; i++){
			for(int j=0; j<3; j++){
				linha[i] += m[i][j];
				coluna[j] += m[i][j];
				if(i==j) diag1 += m[i][j];
				if(j==3-i-1) diag2 += m[i][j];
			}
		}
		
		if(linha[0] == 2 || linha[1] == 2 || linha[2] == 2 ||
			coluna[0] == 2 || coluna[1] == 2 || coluna[2] == 2 ||
			diag1 == 2 || diag2 == 2) printf("SIM\n");
		else
			printf("NAO\n");
	}
	
}
